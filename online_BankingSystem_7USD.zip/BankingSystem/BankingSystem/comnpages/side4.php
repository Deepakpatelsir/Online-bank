<div class="entry-meta">
    <span id="publish_date">Debit/Credit Card</span>
    <span><i class="fa fa-user"></i> <a href="./cardApply.php">Apply Online</a></span>
    <span><i class="fa fa-comment"></i> <a href="./Card.php">All Card </a></span>
      
</div>