<div class="entry-meta">
    <span id="publish_date">Loan</span>
    <span><i class="fa fa-user"></i> <a href="./LoanApply.php">Apply Online</a></span>
    <span><i class="fa fa-comment"></i> <a href="./AllLoan.php">All Loan</a></span>
    <span><i class="fa fa-heart"></i><a href="./LoanDetails.php">Loan Details</a></span>    
</div>