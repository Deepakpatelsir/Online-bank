<div class="entry-meta">
    <span id="publish_date">Transactions</span>
    <span><i class="fa fa-user"></i> <a href="./AddPayee.php">Add Payee</a></span>
    <span><i class="fa fa-user"></i> <a href="./payee.php">All Payee</a></span>
    <span><i class="fa fa-comment"></i> <a href="./FundTransfer.php">Fund Transfer</a></span>
    <span><i class="fa fa-heart"></i><a href="./FundDeposite.php">Fund Deposit</a></span>
    <span><i class="fa fa-heart"></i><a href="./statement.php">Statements</a></span>
    
</div>