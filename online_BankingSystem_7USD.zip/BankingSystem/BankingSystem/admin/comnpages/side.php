 <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">                
                  <li class="active">
                      <a class="" href="index.php">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>
				  
				  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Accounts</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="UserAccountOpenRequest.php">New Account Request</a></li>
						  <!--<li><a class="" href="OpenAccount.php">Open An Account</a></li>                          -->
                          <li><a class="" href="ViewAccount.php">View Account Details</a></li>
                          <!--<li><a class="" href="TerminateAccount.php">Terminate An Account</a></li>-->
						  <li><a class="" href="ApprovedAccount.php">Approved Account</a></li>
						  <li><a class="" href="RejectedAccount.php">Rejected Account</a></li>
						  <li><a class="" href="TerminatedAccount.php">Terminated Account</a></li>
                      </ul>
                  </li>
				  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Lone</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="./addLoan.php">Add Loan</a></li>                          
                          <li><a class="" href="./LoanRequest.php">Lone Request</a></li>                          
                          <li><a class="" href="./Loan.php">All Lone</a></li>
                          <!--<li><a class="" href="./ClosedLoan.php">Closed Lone</a></li>-->
                      </ul>
                  </li>  

					<li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Debit/Credit Card</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                                                
                          <li><a class="" href="./cardRequest.php">Card Request</a></li>                          
                          <li><a class="" href="./card.php">All Card</a></li>
                          <!--<li><a class="" href="./ClosedLoan.php">Closed Lone</a></li>-->
                      </ul>
                  </li> 
				  
                  
                  <li>
                      <a class="" href="query.php">
                          <i class="icon_genius"></i>
                          <span>User Enquiry</span>
                      </a>
                  </li>
                 
                             
                  
                      
                  
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
     