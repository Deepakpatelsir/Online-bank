<div class="text-right">
          <div class="credits">
                <a href="#">Banking System </a> by <a href="#">Worldsoft Technologies Pvt. Ltd.</a>
            </div>
        </div>